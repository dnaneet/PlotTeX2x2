#!/bin/bash
#set -x
#shopt -s xpg_echo
#Creates 2x2 subplots from *.png files in a folder.
#This can be easily modified to create other tiles of plots if one so wishes.
#YOU MUST CREATE A folder called "details" in the current directory. You can
#edit this file to circumvent this folder and just create files in the current
#directory.
#----------------------------------------------------------------------------------
#Created by Aneet D N / dnaneet@mtu.edu || Please feel free to modify or distribute
# with acknowledgement to original author.
#----------------------------------------------------------------------------------

clear
rm *.tex
#Number of *.png files
fileNum=$(ls -l *dft_0_corner.png | wc -l)

#(initNum+1) is used for the figure \label{} in the eventual latex file
initNum=0

read -p "Press [Enter] key to continue..."


 ls *dft_0_corner.png | sed -e 's/\.[a-zA-Z]*$//' > ./details/dft_0_corner.file
 ls *dft_corner_Rup.png | sed -e 's/\.[a-zA-Z]*$//' > ./details/dft_corner_Rup.file
 ls *profile_0.png | sed -e 's/\.[a-zA-Z]*$//' > ./details/profile_0.file
 ls *profile_Rup.png | sed -e 's/\.[a-zA-Z]*$//' > ./details/profile_Rup.file



pwd=$(pwd)






for i in $(eval echo {1..$fileNum})

do
pngCorner0=$(awk 'NR=='$i './details/dft_0_corner.file')
figpathCorner0=$pwd/$pngCorner0'.png'
pngCornerRup=$(awk 'NR=='$i './details/dft_corner_Rup.file')
figpathCornerRup=$pwd/$pngCornerRup'.png'
pngZeroProfile=$(awk 'NR=='$i './details/profile_0.file')
figpathZeroProfile=$pwd/$pngZeroProfile'.png'
pngRupProfile=$(awk 'NR=='$i './details/profile_Rup.file')
figpathRupProfile=$pwd/$pngRupProfile'.png'


label=$((initNum+i))
 figsublabel="sub"$label
 figlabel="fig"$label
 

 incgrphx="
	\begin{figure} 
   	 \centering
	    \subfloat{\includegraphics[width=0.45\linewidth]{$figpathZeroProfile}\label{$figsublabel"a"}} 
	    \subfloat{\includegraphics[width=0.45\linewidth]{$figpathRupProfile}\label{$figsublabel"b"}} \\\ 
	    \subfloat{\includegraphics[width=0.45\linewidth]{$figpathCorner0}\label{$figsublabel"c"}}
	    \subfloat{\includegraphics[width=0.4\linewidth]{$figpathCornerRup}\label{$figsublabel"d"}}
	 \caption{Caption goes here}
	\end{figure} "



echo $'\n'$incgrphx >> include_grphx.tex
done
echo $label > init_file_num

texFile="
\documentclass[a4paper,10pt]{article}
\usepackage[margin=2.5cm,letterpaper]{geometry}
\usepackage{subfig}
\usepackage{amsmath}
\usepackage{amsfonts}
\usepackage{amssymb}
\usepackage{caption}
\usepackage{graphicx}
\usepackage[T1]{fontenc} 
\usepackage{float}
\usepackage{grffile}
\begin{document} "

echo $texFile >> preamble.tex
cat preamble.tex include_grphx.tex > output.tex
echo "\end{document}" >> output.tex


#Use pdflatex with "nonstop" interaction mode to create output.pdf
pdflatex -interaction=nonstopmode output.tex 

echo "Done!"


